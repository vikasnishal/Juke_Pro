var wooqerFilter=angular.module('jukeApp.filters',[]);
var wooqerService=angular.module('jukeApp.filters');

