var jukeDirective=angular.module('jukeApp.directives',[]);

