Juke_Pro
========

Youtube player

---------------
Functionalities Covered in this version are:

1. data maintenance
	1.1playlist is maintained even after browser shuts down.
2. previous and next button.
	2.1previous button will be faded if its the first video in the playlist.
	2.2next button will be faded if its last video in the playlist.
3. shuffle
	3.1 if shuffle is enabled then both previous and next button will be working irrespective of video number currently playing.
	3.2 if shuffle is on then clicking on previous and next will lead to a new video with random count.
4. repeat
	4.1 when repeat is on, clicking on next or previous will lead to respective video and the new video will be on repeat mode.